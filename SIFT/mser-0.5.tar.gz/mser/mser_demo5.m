I=imread('data/car1.jpg') ;
I=imresize(I,[32 32]) ;
[r,m]=mser(I,3) ;
