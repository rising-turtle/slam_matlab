#!/bin/bash

#./clusterrun.sh shapes_basic
./clusterrun.sh faces_basic
#./clusterrun.sh shapes_haar
#./clusterrun.sh faces_haar
#./clusterrun.sh faces_full
