% PLOT_SHAPES_HAAR
load('results/shapes_haar') ;
plotexp(rs, {'ntrain','nhaar'},'ntrain','shapes_haar') ;

