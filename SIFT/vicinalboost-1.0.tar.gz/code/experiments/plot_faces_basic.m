% PLOT_FACES_BASIC
load('results/faces_basic') ;
plotexp(rs, {'use_gd','use_tg','sigma','ntrain'},'sigma','faces_basic') ;
