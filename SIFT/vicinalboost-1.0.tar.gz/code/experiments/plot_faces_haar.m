% PLOT_FACES_HAAR
load('results/faces_haar') ;
plotexp(rs, {'ntrain','nhaar'},'ntrain', 'faces_haar') ;
