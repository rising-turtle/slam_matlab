% PLOT_FACES_FULL
load('results/faces_full') ;
plotexp(rs, {'sigma','use_tg','use_gd'},'sigma', 'faces_full') ;
