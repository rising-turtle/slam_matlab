% PLOT_SHAPES_BASIC
load('results/shapes_basic') ;
plotexp(rs, {'use_gd','use_tg','sigma','ntrain'},'sigma','shapes_basic') ;