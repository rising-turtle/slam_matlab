% PLOT_FACES_TEST
load('results/faces_test') ;
plotexp(rs, {'sigma','tg_scale','init_wc_s0','init_wc_s1','gd_niters','gd_method'},'sigma','faces_test') ;
